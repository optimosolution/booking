WhRedactor widget
=================
The Redactor WYSIWYG widget is free software. Every part of this
project except `assets` directory is released under the terms of the following
BSD License.
license http://www.opensource.org/licenses/bsd-license.php New BSD License

Copyright ©; by 2amigos.us 2013-

Imperavi Redactor
=================

Redactor that is located at `assets` directory is not an open-source product but
a proprietary commercial copyrighted software. Yii community bought OEM license
for it so you are free to use it if you are using Yii.