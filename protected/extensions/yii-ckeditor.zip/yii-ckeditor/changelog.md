Changelog
=========

0.1.1
---

- **(fix)** #356: some fixes

0.1
---

- Initial release