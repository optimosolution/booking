<?php
/**
 * Russian translation for X-editable.
 * 
 * @author Vitaliy Potapov <noginsk@rambler.ru>
*/

return array (
  'Enter'     => 'Введите',
  'Select'    => 'Выберите',
  'Pick'      => 'Укажите',
  'x clear'   => 'очистить',
);
